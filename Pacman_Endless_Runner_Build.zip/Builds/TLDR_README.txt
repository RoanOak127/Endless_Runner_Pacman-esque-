Each level is 30 seconds, the goal is to survive and move on to the next level and see how far you can get. 

UI:

	- Your life is at the bottom middle, it starts out at 50 and the game is over if it reaches 0.
	- Time is at the top middle, it counts down
	- Level is top left
	- Points is top right, every 100 points you get +10 to your life

Controlls:
	Arrow Keys:
	<- move left
	-> move right
	^ jump up
	v fall down directly while jumping
	
	Z - pause/unpause game
	space - jump up
	Mouse click for buttons

Enemies:
	- Red pyrmids == red ghosts: instant death if touched, moves forward and backwards along the platform
	- Black and Blue walls: -10 to health on impact
	Falling off the Platform: instant death once far enough away
	
Items:
	- Strawberries: stops all enemies for the remainder of the level
	- Mushrooms: Slows your speed down
	
	